@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo ========================================
echo           craTe. EXE BUILDER
echo ========================================
echo.
where node >nul 2>&1
if errorlevel 1 (echo Node.js is required only for the build.&pause&exit /b 1)
call npm install
if errorlevel 1 (echo npm install failed.&pause&exit /b 1)
if not exist dist mkdir dist
call npx @yao-pkg/pkg . --targets host --output dist\craTe.exe
if errorlevel 1 (echo Build failed.&pause&exit /b 1)
echo.
echo DONE: dist\craTe.exe
echo The EXE contains the web UI and server internally.
echo Radmin VPN clients on the same 26.x network can auto-discover a host.
echo Keep data.json next to the EXE for accounts/messages.
echo.
pause
