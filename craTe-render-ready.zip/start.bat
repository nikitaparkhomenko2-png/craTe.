@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist node_modules (
  echo Installing dependencies...
  call npm install
  if errorlevel 1 (
    echo.
    echo npm install failed.
    pause
    exit /b 1
  )
)

set "RADMIN_IP="
set "LAN_IP="
for /f "tokens=2 delims=:" %%A in ('ipconfig ^| findstr /R /C:"26\.[0-9][0-9]*\.[0-9][0-9]*\.[0-9][0-9]*"') do if not defined RADMIN_IP set "RADMIN_IP=%%A"
for /f "tokens=*" %%A in ("%RADMIN_IP%") do set "RADMIN_IP=%%A"
for /f "tokens=2 delims=:" %%A in ('ipconfig ^| findstr /R /C:"IPv4.*[0-9]\.[0-9]\.[0-9]\.[0-9]"') do if not defined LAN_IP set "LAN_IP=%%A"
for /f "tokens=*" %%A in ("%LAN_IP%") do set "LAN_IP=%%A"

netsh advfirewall firewall add rule name="craTe LAN TCP 3000" dir=in action=allow protocol=TCP localport=3000 profile=any >nul 2>&1

cls
echo ========================================
echo                 craTe.
echo ========================================
echo.
echo Your computer:
echo http://localhost:3000
if defined RADMIN_IP (
  echo.
  echo For other devices in your Radmin VPN network:
  echo http://%RADMIN_IP%:3000
) else (
  echo.
  echo Radmin VPN was not detected.
  echo Connect to your Radmin VPN network and restart this file.
)
if defined LAN_IP (
  echo.
  echo For your phone / devices on the same Wi-Fi:
  echo http://%LAN_IP%:3000
) else (
  echo.
  echo Wi-Fi/LAN IP was not detected.
)
echo.
where ollama >nul 2>&1
if errorlevel 1 (
  echo neXi AI: Ollama не найден. Мессенджер работает, AI будет офлайн.
) else (
  echo neXi AI: Ollama найден. Используется локальная модель без API-ключа.
)
echo.
echo Keep this window open while craTe. is running.
echo ========================================
echo.
call npm start
echo.
echo ========================================
echo craTe server stopped. Exit code: %errorlevel%
echo Check the messages above for the exact error.
echo ========================================
pause
