@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist "dist\craTe.exe" (
  echo craTe.exe not found. Run build-exe.bat first.
  pause
  exit /b 1
)
if not exist data.json echo {"users":[],"messages":[],"groups":[]} > data.json
start "craTe." "%~dp0dist\craTe.exe"
